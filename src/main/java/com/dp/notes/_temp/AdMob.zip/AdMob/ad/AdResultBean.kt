package com.demo.admodx.ad

/**
 * author Dq
 * date on 2024/7/24
 * description 广告显示结束的回调
 */
data class AdResultBean(
    val unitId: String = "",     //广告id
    val action: String = "",     //显示广告类型
    val taskId: String = "",     //对应的任务id
    val customData: String = "", //透传给Google数据
    var result: Int = 0,         //结果:0失败,1成功
    var error: String? = null,   //错误信息
) {
    fun setResult(error: String?) {
        this.result = if (error == null) 1 else 0
        this.error = error
    }
}