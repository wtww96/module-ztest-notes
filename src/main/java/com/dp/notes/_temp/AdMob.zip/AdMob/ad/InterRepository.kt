package com.demo.admodx.ad

import android.app.Activity
import com.demo.admodx.util.CommonApp
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * author Dq
 * date on 2024/7/22
 * description 插页式广告
 */
class InterRepository : AdRepository<InterstitialAd>() {

    override fun handleLoadAd() {
        val request = AdRequest.Builder().build()
        InterstitialAd.load(CommonApp.application, id, request, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) = loadedSuccess(ad)
            override fun onAdFailedToLoad(error: LoadAdError) = loadedFinish(error)
        })
    }

    override fun handleShowAd(activity: Activity) {
        ad?.show(activity)
        ad?.fullScreenContentCallback = object : FullScreenContentCallback() {
            /** 全屏广告-展示了内容 */
            //override fun onAdShowedFullScreenContent() {}
            /** 全屏广告-无法显示内容 */
            override fun onAdFailedToShowFullScreenContent(error: AdError) = loadedFinish(error)

            /** 全屏广告-关闭 */
            override fun onAdDismissedFullScreenContent() = showCompleted()
        }
    }
}