package com.demo.admodx.ad

import android.annotation.SuppressLint
import android.util.Log
import android.view.ViewGroup
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.demo.admodx.ad.AdRepository.Companion.TAG
import com.demo.admodx.util.CommonApp
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * author Dq
 * date on 2024/8/8
 * description 横幅广告
 */
class BannerRepository : DefaultLifecycleObserver {
    //广告预加载数量,最多5个
    private val preloadNum = 4

    //预加载缓存的广告
    private val preloadAds = mutableListOf<AdResponseBean<AdView>>()
    private var adChannel: Channel<AdResponseBean<AdView>>? = null
    private var isLoading = false

    /**
     * @param adId 广告id
     * @param unique 广告本地唯一标识,缓存使用
     * @param adSize 其中的宽高需要传dp的数值(360.dp 传360)
     */
    fun show(lifecycleOwner: LifecycleOwner, adId: String, unique: String, adSize: AdSize, container: ViewGroup) {
        Log.d(TAG, ">>>>>>横幅广告:缓存preloadAds=${preloadAds.map { it.unique }}")
        lifecycleOwner.lifecycle.addObserver(this)
        //优先加载缓存广告
        preloadAds.find { it.checkLocalAd(unique) }?.let {
            displayAd(it, unique, container)
        } ?: run {
            //初始化Channel,请求广告
            adChannel = adChannel ?: Channel(preloadNum)
            preload(adId, adSize) {
                val bean = AdResponseBean(it, System.currentTimeMillis())
                preloadAds.add(bean)
                //try Channel was closed
                runCatching { adChannel?.trySend(bean) }
            }
            //Channel 接收显示广告
            lifecycleOwner.lifecycleScope.launch {
                //try Channel was closed
                runCatching {
                    displayAd(adChannel?.receive(), unique, container)
                }
            }
        }
    }

    /**
     * 预加载广告
     */
    @SuppressLint("MissingPermission")
    private fun preload(adId: String, adSize: AdSize, callback: (AdView) -> Unit) {
        Log.d(TAG, ">>>>>>横幅广告:preload,isLoading=$isLoading")
        if (isLoading) return
        isLoading = true
        //请求广告的异步转协程
        suspend fun requestAd(): AdView? = suspendCancellableCoroutine {
            val adView = AdView(CommonApp.application.applicationContext)
            adView.adUnitId = adId
            adView.setAdSize(adSize)
            adView.loadAd(AdRequest.Builder().build())
            adView.adListener = object : AdListener() {
                //广告加载失败
                override fun onAdFailedToLoad(error: LoadAdError) {
                    if (it.isActive) {
                        Log.d(TAG, ">>>>>>横幅广告:加载失败,error=$error")
                        it.resume(null)
                    }
                }

                //加载成功,Google广告会不定时的自动刷新已加载过的广告,触发此回调
                override fun onAdLoaded() {
                    if (it.isActive) {
                        Log.d(TAG, ">>>>>>横幅广告:加载成功,AD=${adView.hashCode()}")
                        it.resume(adView)
                    }
                }

                //广告点击
                //override fun onAdClicked() {}
                //广告关闭
                //override fun onAdClosed() {}
            }
        }

        CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
            Log.d(TAG, ">>>>>>横幅广告:加载中...")
            (1..preloadNum).map {
                async { requestAd()?.let(callback) }
            }.awaitAll()
            isLoading = false
            Log.d(TAG, ">>>>>>横幅广告:加载完成.")
        }
    }

    /**
     * 获取到广告了,展示
     */
    private fun displayAd(bean: AdResponseBean<AdView>?, unique: String, container: ViewGroup) {
        Log.d(TAG, ">>>>>>横幅广告:显示.curUnique=$unique,getUnique=${bean?.unique},AD=${bean?.ad.hashCode()}")
        bean?.runCatching {
            //广告已使用,添加标记
            bean.unique = unique
            (bean.ad.parent as? ViewGroup)?.removeView(bean.ad)
            container.removeAllViews()
            container.addView(bean.ad)
        }
    }

    /**
     * 广告加载的页面销毁,移除掉已使用的广告
     */
    override fun onDestroy(owner: LifecycleOwner) {
        Log.e(TAG, ">>>>>>横幅广告页面销毁:移除已使用的广告,size=${preloadAds.map { "${it.ad.hashCode()}--${it.unique}" }}")
        adChannel?.close()
        adChannel = null
        val iterator = preloadAds.iterator()
        while (iterator.hasNext()) {
            val ad = iterator.next()
            if (ad.unique != null) {
                Log.e(TAG, ">>>>>>横幅广告页面销毁:remove ad.unique=${ad.unique}")
                (ad.ad.parent as? ViewGroup)?.removeView(ad.ad)
                ad.ad.destroy()
                iterator.remove()
            }
        }
        Log.e(TAG, ">>>>>>横幅广告页面销毁剩余缓存,size=${preloadAds.map { it.unique }}")
    }
}