package com.demo.admodx.ad

import android.app.Application
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LifecycleOwner
import com.demo.admodx.databinding.AdUnifiedBinding
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.VideoController
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * author Dq
 * date on 2024/7/19
 * description
 */
object AdHelper {
    //插页式广告
    //private const val AD_ID_INTER = "ca-app-pub-4142769677696436/9667361909" //vone
    private const val AD_ID_INTER = "ca-app-pub-3940256099942544/8691691433"

    //激励广告
    //private const val AD_ID_REWARD = "ca-app-pub-4142769677696436/3513001181" //vone
    private const val AD_ID_REWARD = "ca-app-pub-3940256099942544/5224354917"

    //原生广告
    //private const val AD_ID_NATIVE = "ca-app-pub-4142769677696436/9364109571" //vone
    private const val AD_ID_NATIVE = "ca-app-pub-3940256099942544/1044960115"

    //横幅广告
    //private const val AD_ID_NATIVE = "ca-app-pub-4142769677696436/9364109571" //vone
    private const val AD_ID_BANNER = "ca-app-pub-3940256099942544/9214589741"

    private val interRepository by lazy { InterRepository() }
    private val rewardRepository by lazy { RewardRepository() }
    private val nativeRepository by lazy { NativeRepository() }
    private val bannerRepository by lazy { BannerRepository() }

    /**
     * 初始化
     */
    fun initialize(application: Application) {
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(application) {}
            //无google服务的会抛出异常
            runCatching {
                val deviceAdId = AdvertisingIdClient.getAdvertisingIdInfo(application).id
                Log.e("AdMob", "deviceAdId=$deviceAdId")
            }
        }
    }

    /**
     * 插页广告
     */
    fun loadInter() {
        interRepository.loadAd(AD_ID_INTER)
    }

    fun showInter(activity: AppCompatActivity) {
        interRepository.show(activity, AD_ID_INTER) {
            Log.e("AdMob", "----------------------> 插页广告 已加载,可以显示")
        }.withAdCompleted {
            Log.e("AdMob", "----------------------> 插页广告 显示完成,error=$it")
        }
    }

    fun showBanner(lifecycleOwner: LifecycleOwner, viewGroup: ViewGroup, xx: String) {
        //bannerRepository.show(viewGroup, "", AdSize(360, 90))
        bannerRepository.show(lifecycleOwner, AD_ID_BANNER, xx, AdSize(360, 90), viewGroup)
    }

    /**
     * 激励广告
     */
    fun loadReward() {
        rewardRepository.loadAd(AD_ID_REWARD)
    }

    fun showReward(activity: AppCompatActivity) {
        rewardRepository.show(activity, AD_ID_REWARD) {
            Log.e("AdMob", "----------------------> 激励广告 已加载,可以显示")
        }.withAdCompleted {
            Log.e("AdMob", "----------------------> 激励广告 显示完成,error=$it")
            //预加载下一次
            rewardRepository.loadAd(AD_ID_REWARD)
        }
    }

    /**
     * 原生广告
     */
    fun loadNative() {
        //nativeRepository.loadAd(AD_ID_NATIVE)
    }

    fun showNative(activity: AppCompatActivity, root: ViewGroup, xx: String) {
        nativeRepository.show(activity, AD_ID_NATIVE, xx) {
            Log.e("AdMob", "----------------------> 原生广告 显示")
            val unifiedAdBinding = AdUnifiedBinding.inflate(activity.layoutInflater)
            root.removeAllViews()
            root.addView(unifiedAdBinding.root)
            //填充原生广告视图
            displayNativeAd(it, unifiedAdBinding)
        }
//        nativeRepository.show(activity, AD_ID_NATIVE) { ad ->
//            Log.e("AdMob", "----------------------> 原生广告 已加载,可以显示")
//            val unifiedAdBinding = AdUnifiedBinding.inflate(activity.layoutInflater)
//            root.removeAllViews()
//            root.addView(unifiedAdBinding.root)
//            //填充原生广告视图
//            displayNativeAd(ad, unifiedAdBinding)
//        }.withAdCompleted {
//            Log.e("AdMob", "----------------------> 原生广告 显示完成,error=$it")
//        }
    }

    /**
     * 填充原生广告数据
     * @param nativeAd - 原生广告
     * @param unifiedAdBinding - 显示原始广告的View(以NativeAdView为根布局)
     */
    private fun displayNativeAd(nativeAd: NativeAd, unifiedAdBinding: AdUnifiedBinding) {
        val nativeAdView = unifiedAdBinding.root

        // 设置媒体视图。
        nativeAdView.mediaView = unifiedAdBinding.adMedia

        // 设置其他广告资产。
        nativeAdView.headlineView = unifiedAdBinding.adHeadline
        nativeAdView.bodyView = unifiedAdBinding.adBody
        nativeAdView.callToActionView = unifiedAdBinding.adCallToAction
        nativeAdView.iconView = unifiedAdBinding.adAppIcon
        nativeAdView.priceView = unifiedAdBinding.adPrice
        nativeAdView.starRatingView = unifiedAdBinding.adStars
        nativeAdView.storeView = unifiedAdBinding.adStore
        nativeAdView.advertiserView = unifiedAdBinding.adAdvertiser

        // 保证标题和媒体内容出现在每个uniednativead中。
        unifiedAdBinding.adHeadline.text = nativeAd.headline
        nativeAd.mediaContent?.let { unifiedAdBinding.adMedia.mediaContent = it }

        // 这些资产不能保证在每个uniednativead中都存在，所以很重要的一点是
        // 在尝试显示它们之前进行检查。
        if (nativeAd.body == null) {
            unifiedAdBinding.adBody.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adBody.visibility = View.VISIBLE
            unifiedAdBinding.adBody.text = nativeAd.body
        }

        if (nativeAd.callToAction == null) {
            unifiedAdBinding.adCallToAction.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adCallToAction.visibility = View.VISIBLE
            unifiedAdBinding.adCallToAction.text = nativeAd.callToAction
        }

        if (nativeAd.icon == null) {
            unifiedAdBinding.adAppIcon.visibility = View.GONE
        } else {
            unifiedAdBinding.adAppIcon.setImageDrawable(nativeAd.icon?.drawable)
            unifiedAdBinding.adAppIcon.visibility = View.VISIBLE
        }

        if (nativeAd.price == null) {
            unifiedAdBinding.adPrice.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adPrice.visibility = View.VISIBLE
            unifiedAdBinding.adPrice.text = nativeAd.price
        }

        if (nativeAd.store == null) {
            unifiedAdBinding.adStore.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adStore.visibility = View.VISIBLE
            unifiedAdBinding.adStore.text = nativeAd.store
        }

        if (nativeAd.starRating == null) {
            unifiedAdBinding.adStars.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adStars.rating = nativeAd.starRating!!.toFloat()
            unifiedAdBinding.adStars.visibility = View.VISIBLE
        }

        if (nativeAd.advertiser == null) {
            unifiedAdBinding.adAdvertiser.visibility = View.INVISIBLE
        } else {
            unifiedAdBinding.adAdvertiser.text = nativeAd.advertiser
            unifiedAdBinding.adAdvertiser.visibility = View.VISIBLE
        }

        // 显示广告,必须调用
        nativeAdView.setNativeAd(nativeAd)

        // 为广告准备视频控制器。即使广告没有提供，也总会提供一个
        // 拥有视频资产。
        val mediaContent = nativeAd.mediaContent
        val vc = mediaContent?.videoController
        // 更新UI以显示此广告是否具有视频资产。
        if (vc != null && mediaContent.hasVideoContent()) {
            Log.e("hehe", "--------------- 视频播放监听")
            // 创建一个新的videolifecycle ecallbacks对象并将其传递给VideoController。的
            // 当视频中发生事件时，VideoController将调用该对象的方法
            // 生命周期。
            vc.videoLifecycleCallbacks = object : VideoController.VideoLifecycleCallbacks() {
                override fun onVideoEnd() {
                    // 发行商应该允许原生广告在完成视频播放之前
                    // 在相同的UI位置用另一个广告刷新或替换它们。
                    //binding.btClick.isEnabled = true
                    //binding.videostatusText.text = "视频状态:视频播放已结束。"
                    Log.e("hehe", "--------------- onVideoEnd")
                    super.onVideoEnd()
                }
            }
        } else {
            //mainActivityBinding.videostatusText.text = "视频状态:广告中不包含视频资产"
            //binding.btClick.isEnabled = true
        }
    }
}