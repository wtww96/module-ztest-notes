package com.demo.admodx.ad

import android.app.Activity
import com.demo.admodx.util.CommonApp
import com.demo.admodx.util.SPTools
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions

/**
 * author Dq
 * date on 2024/7/22
 * description 激励广告
 */
class RewardRepository : AdRepository<RewardedAd>() {

    private var customData = ""

    /**
     * 设置CustomData
     */
    fun setCustomData(customData: String) {
        this.customData = customData
    }

    override fun handleLoadAd() {
        val request = AdRequest.Builder().build()
        RewardedAd.load(CommonApp.application, id, request, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) = loadedSuccess(ad)
            override fun onAdFailedToLoad(error: LoadAdError) = loadedFinish(error)
        })
    }

    override fun handleShowAd(activity: Activity) {
        val options = ServerSideVerificationOptions.Builder()
            .setCustomData(customData)
            .setUserId(SPTools.userId.toString())
            .build()
        ad?.setServerSideVerificationOptions(options)
        ad?.show(activity) { showCompleted() }
        ad?.fullScreenContentCallback = object : FullScreenContentCallback() {
            /** 全屏广告-无法显示内容 */
            override fun onAdFailedToShowFullScreenContent(error: AdError) = loadedFinish(error)
        }
    }
}