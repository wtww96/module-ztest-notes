package com.demo.admodx.ad

/**
 * author Dq
 * date on 2024/8/8
 * description 请求广告
 */
data class AdResponseBean<T>(
    val ad: T,
    val requestTime: Long,      //广告请求成功的时间,广告有效期1h
    var unique: String? = null, //广告本地唯一标识
) {
    /**
     * 校验本地缓存的广告是否可用
     */
    fun checkLocalAd(unique: String): Boolean {
        //缓存广告是否可用
        val isCanUse = this.unique == unique || this.unique == null

        //广告已请求后的时间,超过1h清除当前广告,重新加载
        val timeDifference = System.currentTimeMillis() - requestTime

        return isCanUse && timeDifference < 1000 * 60 * 60
    }
}