package com.demo.admodx.ad

import android.app.Activity
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.demo.admodx.util.ActivityList
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.nativead.NativeAd


/**
 * author Dq
 * date on 2024/7/23
 * description 广告获取类,广告有效期为1小时
 */
abstract class AdRepository<T> {
    private val adName = this::class.java.simpleName

    //广告id,由外部传入.同一种类型广告可能会有多个id
    protected var id = ""

    //同时只会存在一个可用广告,不管传入的id是什么
    protected var ad: T? = null

    //广告加载完成回调
    private var loadedBlock: (() -> Unit)? = null

    //广告显示完成回调
    private var completedBlock: ((error: String?) -> Unit)? = null

    //广告是否加载中
    private var isLoading = false

    //广告是否显示中
    private var isShowing = false

    //广告最新请求的时间
    private var requestTime = 0L

    protected abstract fun handleLoadAd()
    protected open fun handleShowAd(activity: Activity) {}

    /**
     * 预加载广告
     * @param id 广告id
     */
    fun loadAd(id: String) {
        this.id = id
        //------------
        checkAdValidity()
        //加载中
        if (isLoading) return
        //已有加载好的广告
        if (ad != null) return
        Log.d(TAG, "-- $adName: 请求广告中...")
        isLoading = true
        handleLoadAd()
        requestTime = System.currentTimeMillis()
    }

    /**
     * 显示广告
     * @param id 广告id
     * @param showBlock 回调加载好的广告对象,处理显示广告逻辑
     */
    fun show(activity: Activity, id: String, showBlock: ((T) -> Unit)? = null) = apply {
        this.id = id
        //------------
        checkAdValidity()
        if (isShowing) return@apply
        isShowing = true

        //开始显示广告
        fun startShowAd() {
            //回调完后置空,避免有预加载的广告再次触发
            loadedBlock = null
            //页面没有结束,并且处于前台才能正常显示广告
            ad?.takeIf { !activity.isFinishing && ActivityList.appIsForeground() }?.let {
                showBlock?.invoke(it)
                handleShowAd(activity)
            }
        }
        //优先使用缓存的广告对象
        if (ad != null) {
            startShowAd()
        } else {
            loadedBlock = ::startShowAd
            loadAd(id)
        }
        //页面关闭,重置显示状态
        (activity as? LifecycleOwner)?.lifecycle?.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                isShowing = false
            }
        })
    }

    /**
     * 广告完成监听
     */
    fun withAdCompleted(completedBlock: (error: String?) -> Unit) {
        this.completedBlock = completedBlock
    }

    //====================================================================

    /**
     * 校验广告是否过期,AdMob广告大约1h过期
     * @return true:有效广告
     */
    private fun checkAdValidity() {
        //广告已请求后的时间,超过1h清除当前广告,重新加载
        val timeDifference = System.currentTimeMillis() - requestTime
        //1000 * 60 * 60
        if (ad != null && timeDifference >= 1000 * 60 * 60) {
            Log.d(TAG, "-- $adName: 广告过期,重新加载")
            isLoading = false
            resetAdShow()
        }
    }

    /**
     * 重置广告显示状态 和 对象
     */
    private fun resetAdShow() {
        Log.d(TAG, "-- $adName: resetAdShow")
        isShowing = false
        //如果是原生广告,先销毁
        (ad as? NativeAd)?.destroy()
        ad = null
    }

    /**
     * 加载成功
     */
    protected fun loadedSuccess(ad: T) {
        Log.d(TAG, "-- $adName: loadedSuccess")
        //如果是原生广告,先销毁上一次的
        (this.ad as? NativeAd)?.destroy()
        this.ad = ad
        isLoading = false
        loadedBlock?.invoke()
    }

    /**
     * 加载结束
     * code=0 : 连接广告服务器出错,超时
     * code=1 : 广告已显示过/没有广告
     * code=2 : 网络错误,广告尚未准备好
     * code=3 : 应用处于后台,无法显示广告,可以下次再使用
     */
    protected fun loadedFinish(error: AdError) {
        Log.d(TAG, "-- $adName: loadedFinish,code:${error.code}")
        isLoading = false
        showCompleted(error)
    }

    /**
     * 显示完成,重置,通知外部
     * @param error 失败信息
     */
    protected fun showCompleted(error: AdError? = null) {
        Log.d(TAG, "-- $adName: showCompleted")
        resetAdShow()
        completedBlock?.invoke(error?.message)
    }

    companion object {
        const val TAG = "AdMob"
    }
}