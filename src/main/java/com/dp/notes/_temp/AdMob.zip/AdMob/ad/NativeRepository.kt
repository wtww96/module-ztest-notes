package com.demo.admodx.ad

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.demo.admodx.ad.AdRepository.Companion.TAG
import com.demo.admodx.util.CommonApp
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MediaAspectRatio
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * author Dq
 * date on 2024/7/23
 * description 原生广告
 */
class NativeRepository : DefaultLifecycleObserver {
    //广告预加载数量,最多5个
    private val preloadNum = 4

    //预加载缓存的广告
    private val preloadAds = mutableListOf<AdResponseBean<NativeAd>>()
    private var adChannel: Channel<AdResponseBean<NativeAd>>? = null
    private var adLoader: AdLoader? = null

    /**
     * @param adId 广告id
     * @param unique 广告本地唯一标识,缓存使用
     */
    fun show(lifecycleOwner: LifecycleOwner, adId: String, unique: String, callback: (NativeAd) -> Unit) {
        Log.d(TAG, "-- 原生广告:  缓存,preloadAds=${preloadAds.map { it.unique }}")
        lifecycleOwner.lifecycle.addObserver(this)
        //优先加载缓存广告
        preloadAds.find { it.checkLocalAd(unique) }?.let {
            displayAd(it, unique, callback)
        } ?: run {
            //初始化Channel,请求广告
            adChannel = adChannel ?: Channel(preloadNum)
            preload(adId) {
                val bean = AdResponseBean(it, System.currentTimeMillis())
                preloadAds.add(bean)
                //try Channel was closed
                runCatching { adChannel?.trySend(bean) }
            }
            //Channel 接收显示广告
            lifecycleOwner.lifecycleScope.launch {
                //try Channel was closed
                runCatching {
                    displayAd(adChannel?.receive(), unique, callback)
                }
            }
        }
    }

    /**
     * 预加载广告
     */
    @SuppressLint("MissingPermission")
    private fun preload(adId: String, callback: (NativeAd) -> Unit) {
        Log.d(TAG, ">>>>>>>>>>>>原生广告:isLoading=${adLoader?.isLoading}")
        if (adLoader?.isLoading == true) return
        Log.d(TAG, ">>>>>>>>>>>>原生广告:加载中......")
        adLoader = AdLoader.Builder(CommonApp.application.applicationContext, adId)
            .forNativeAd(callback::invoke)
            .withNativeAdOptions(adOptions())
            .withAdListener(object : AdListener() {
                /** 广告请求失败 */
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.d(TAG, ">>>>>>>>>>>>原生广告:加载失败,error=$error")
                }

                /** 广告加载完成 */
                override fun onAdLoaded() {
                    Log.d(TAG, ">>>>>>>>>>>>原生广告:加载成功")
                }
                /** 广告点击 */
                //override fun onAdClicked() {}
                /** 广告点击显示了其他页面(外部应用) */
                //override fun onAdOpened() {}
                /** 广告点击跳转到外部应用后即将返回应用程序,只有初次返回时才触发 */
                //override fun onAdClosed() {}
            }).build()
        adLoader?.loadAds(AdRequest.Builder().build(), preloadNum)
    }

    /**
     * 获取到广告了,展示
     */
    private fun displayAd(bean: AdResponseBean<NativeAd>?, unique: String, callback: (NativeAd) -> Unit) {
        if (null == bean) return
        Log.d(TAG, ">>>>>>>>>>>>原生广告:显示.curUnique=$unique,getUnique=${bean.unique},AD=${bean.ad.hashCode()}")
        //广告已使用,添加标记
        bean.unique = unique
        callback.invoke(bean.ad)
    }

    /**
     * 原生广告的各种配置
     */
    private fun adOptions(): NativeAdOptions {
        val builder = NativeAdOptions.Builder()
        //横纵比
        builder.setMediaAspectRatio(MediaAspectRatio.LANDSCAPE)

        //是否只返回图片url,不下载(客户端自行下载)
        //builder.setReturnUrlsForImageAssets(true)

        //可请求多张图
        builder.setRequestMultipleImages(true)

        //视频是否静音
        val videoOptions = VideoOptions.Builder().setStartMuted(true).build()
        builder.setVideoOptions(videoOptions)

        //广告选择view展示的位置
        builder.setAdChoicesPlacement(NativeAdOptions.ADCHOICES_BOTTOM_LEFT)
        return builder.build()
    }

    /**
     * 广告加载的页面销毁,移除掉已使用的广告
     */
    override fun onDestroy(owner: LifecycleOwner) {
        Log.e(TAG, ">>>>>>>>>>>>原生广告,页面销毁,移除掉已使用的广告,size=${preloadAds.map { "${it.ad.hashCode()}--${it.unique}" }}")
        if (adLoader?.isLoading == false) adLoader = null
        adChannel?.close()
        adChannel = null
        val iterator = preloadAds.iterator()
        while (iterator.hasNext()) {
            val ad = iterator.next()
            if (ad.unique != null) {
                Log.e(TAG, ">>>>>>>>>>>>原生广告页面销毁,移除掉已使用的广告  ad.unique=${ad.unique}")
                ad.ad.destroy()
                iterator.remove()
            }
        }
        Log.e(TAG, ">>>>>>>>>>>>原生广告销毁后,size=${preloadAds.map { it.unique }}")
    }
}